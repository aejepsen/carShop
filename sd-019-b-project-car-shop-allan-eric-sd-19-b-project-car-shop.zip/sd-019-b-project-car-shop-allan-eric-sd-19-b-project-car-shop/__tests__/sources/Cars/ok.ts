import { ICar } from '../../../src/interfaces/ICar';

const testCar: ICar = {
  model: 'Fiat Uno',
  year: 2002,
  color: 'White',
  buyValue: 10000,
  seatsQty: 5,
  doorsQty: 2,
};
