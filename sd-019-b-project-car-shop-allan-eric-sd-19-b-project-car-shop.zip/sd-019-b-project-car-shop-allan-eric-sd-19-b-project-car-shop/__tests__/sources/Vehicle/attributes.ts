import { IVehicle } from "../../../src/interfaces/IVehicle";

const testVehicle: IVehicle = {
  model: 'Fiat Uno',
  year: 2002,
  color: 'White',
  buyValue: 10000,
};
