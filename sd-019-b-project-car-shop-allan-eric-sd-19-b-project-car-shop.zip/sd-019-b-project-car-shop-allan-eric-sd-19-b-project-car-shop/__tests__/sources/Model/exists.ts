import { IModel } from "../../../src/interfaces/IModel";
